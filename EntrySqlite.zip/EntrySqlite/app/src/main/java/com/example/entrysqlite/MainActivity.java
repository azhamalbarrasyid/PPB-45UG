package com.example.entrysqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name, team, position, skill, height;
    Button insert, update, delete, view;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        team = findViewById(R.id.team);
        position = findViewById(R.id.playerPosition);
        skill = findViewById(R.id.skill);
        height = findViewById(R.id.height);


        insert = findViewById(R.id.btnInsert);
        update = findViewById(R.id.btnUpdate);
        delete = findViewById(R.id.btnDelete);
        view = findViewById(R.id.btnView);
        DB = new DBHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String teamTXT = team.getText().toString();
                String playerPositionTXT = position.getText().toString();
                String skillTXT = skill.getText().toString();
                String heightTXT = height.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(nameTXT,teamTXT,playerPositionTXT,skillTXT,heightTXT);
                if (checkinsertdata == true){
                    Toast.makeText(MainActivity.this, "Data Berhasil Ditambahkan", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Data Gagal Ditambahkan", Toast.LENGTH_SHORT).show();
                }
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String teamTXT = team.getText().toString();
                String playerPositionTXT = position.getText().toString();
                String skillTXT = skill.getText().toString();
                String heightTXT = height.getText().toString();

                Boolean checkupdatedata = DB.updateuserdata(nameTXT,teamTXT,playerPositionTXT,skillTXT,heightTXT);
                if (checkupdatedata == true){
                    Toast.makeText(MainActivity.this, "Data Berhasil DiUpdate", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Data Gagal DiUpdate", Toast.LENGTH_SHORT).show();
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                Boolean checkdeletedata = DB.deletedata(nameTXT);
                if (checkdeletedata == true){
                    Toast.makeText(MainActivity.this, "Data Berhasil DiHapus", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Data Gagal DiHapus", Toast.LENGTH_SHORT).show();
                }
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.getData();
                if (res.getCount()==0){
                    Toast.makeText(MainActivity.this, "Tidak ada Data", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("Nama     : "+res.getString(0)+"\n");
                    buffer.append("Team     : "+res.getString(1)+"\n");
                    buffer.append("Position : "+res.getString(2)+"\n");
                    buffer.append("Skill    : "+res.getString(3)+"\n");
                    buffer.append("Tinggi   : "+res.getString(4)+"\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("Input Data Pemain");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
    }
}