package com.example.warung;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
//import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private ArrayList<String> arrayList;
    private ArrayList<Integer> kopiList;
    private ArrayList<String> hargaList;

    RecyclerAdapter(ArrayList<String> arrayList, ArrayList<String> kopiList, ArrayList<Integer> hargaList){
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView namaKopi, hargaKopi;
        private ImageView gambarKopi;
        private LinearLayout itemList;
        private Context context;

        ViewHolder(View itemView){
            super(itemView);

            context = itemView.getContext();

            namaKopi = itemView.findViewById(R.id.coffee);
            hargaKopi = itemView.findViewById(R.id.price);
            gambarKopi = itemView.findViewById(R.id.imagesCoffee);

            itemList = itemView.findViewById(R.id.item_list);
            itemList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent();
                    switch (getAdapterPosition()){
                        case 0 :
                            intent = new Intent(context, V60.class);
                            break;
                        case 1 :
                            intent = new Intent(context, cappucino.class);
                            break;
                        case 3 :
                            intent = new Intent(context, frenchpress.class);
                            break;
                        case 4 :
                            intent = new Intent(context, japanese.class);
                            break;
                    }
                    context.startActivity(intent);
                }
            });
        }
    }

    @NonNull
    @Override
    public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_activity,parent,false);
        ViewHolder VH = new ViewHolder(v);
        return VH;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final String nama = arrayList.get(position);
        final String harga = hargaList.get(position);
        holder.namaKopi.setText(nama);
        holder.hargaKopi.setText(harga);
        holder.gambarKopi.setImageResource(kopiList.get(position));
    }

    @Override
    public int getItemCount() {

        return arrayList.size();
    }



}
