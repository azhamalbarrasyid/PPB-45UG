package com.example.warung;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<String> namaKopi;
    private ArrayList<String> hargaKopi;
    private ArrayList<Integer> gambarKopi;

    // daftar kopi
    private String[] judul = {"V60","Cappucino Latte","French Press","Japanese Iced Coffee"};
    private String[] harga = {"Rp20000","Rp21000","Rp16000","Rp22000"};
    private int[] gambar = {R.drawable.v60,R.drawable.cappucino,R.drawable.frenchpress,R.drawable.japan};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        namaKopi = new ArrayList<>();
        hargaKopi = new ArrayList<>();
        gambarKopi = new ArrayList<>();
        recyclerView = findViewById(R.id.recycler);
        DaftarItem();
        //Menggunakan Layout Manager, Dan Membuat List Secara Vertical
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new RecyclerAdapter(namaKopi,hargaKopi,gambarKopi);

        recyclerView.setAdapter(adapter);
    }

    private void DaftarItem() {
        for (int w=0; w<judul.length; w++){
            namaKopi.add(judul[w]);
            hargaKopi.add(harga[w]);
            gambarKopi.add(gambar[w]);
        }
    }
}
